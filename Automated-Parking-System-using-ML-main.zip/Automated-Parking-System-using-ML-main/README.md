# Automated-Parking-System-using-ML

An Attempt to increase the detection accuracy has been made in this project. 
